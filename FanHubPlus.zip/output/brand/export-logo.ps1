Add-Type -AssemblyName System.Drawing
function Export-Brand([string]$Path, [bool]$Dark) {
    $bmp = [System.Drawing.Bitmap]::new(1040,280)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.Clear($(if($Dark){[System.Drawing.ColorTranslator]::FromHtml('#15111c')}else{[System.Drawing.Color]::Transparent}))
    $g.ScaleTransform(4,4)
    $ink = if($Dark){'#f8f5fc'}else{'#191522'}
    $brush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml($ink))
    $orange = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#ff951b'))
    $gold = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#ffbe47'))
    $letter = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#161923'))
    $saved = $g.Save()
    $g.TranslateTransform(8,11)
    $g.FillPolygon($orange, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(24,2),[System.Drawing.PointF]::new(43,13),[System.Drawing.PointF]::new(43,35),[System.Drawing.PointF]::new(24,46),[System.Drawing.PointF]::new(5,35),[System.Drawing.PointF]::new(5,13)))
    $g.FillPolygon($gold, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(24,2),[System.Drawing.PointF]::new(24,46),[System.Drawing.PointF]::new(5,35),[System.Drawing.PointF]::new(5,13)))
    $g.FillPolygon($letter, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(14,13),[System.Drawing.PointF]::new(34,13),[System.Drawing.PointF]::new(31,20),[System.Drawing.PointF]::new(21,20),[System.Drawing.PointF]::new(21,25),[System.Drawing.PointF]::new(29,25),[System.Drawing.PointF]::new(26,32),[System.Drawing.PointF]::new(21,32),[System.Drawing.PointF]::new(21,38),[System.Drawing.PointF]::new(14,34)))
    $pen = [System.Drawing.Pen]::new($brush,3)
    $pen.StartCap = $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $g.DrawLine($pen,36,5,36,15); $g.DrawLine($pen,31,10,41,10)
    $g.Restore($saved)
    $font = [System.Drawing.Font]::new('Arial',25,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
    $format = [System.Drawing.StringFormat]::GenericTypographic.Clone()
    $format.FormatFlags = $format.FormatFlags -bor [System.Drawing.StringFormatFlags]::MeasureTrailingSpaces
    $x = 65.0
    foreach($ch in 'FanHubPlus'.ToCharArray()) {
       $b = if($x -ge 10000){$brush}else{$brush}
       if($ch -eq 'P') { $brush.Dispose(); $brush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#fca129')) }
       $g.DrawString([string]$ch,$font,$brush,[System.Drawing.PointF]::new($x,17),$format)
       $x += $g.MeasureString([string]$ch,$font,1000,$format).Width - 1
    }
    $small = [System.Drawing.Font]::new('Arial',6.5,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
    $muted = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#969ead'))
    $x = 65.0
    foreach($ch in 'EVERY UNIVERSE. ONE HOME.'.ToCharArray()) {
       $g.DrawString([string]$ch,$small,$muted,[System.Drawing.PointF]::new($x,47),$format)
       $x += $g.MeasureString([string]$ch,$small,1000,$format).Width + 1.5
    }
    $bmp.Save($Path,[System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose(); $font.Dispose(); $small.Dispose(); $pen.Dispose(); $brush.Dispose(); $orange.Dispose(); $gold.Dispose(); $letter.Dispose(); $muted.Dispose(); $format.Dispose()
}
Export-Brand 'D:\FanHubPlus\output\brand\fanhubplus-logo-transparent.png' $false
Export-Brand 'D:\FanHubPlus\output\brand\fanhubplus-logo-dark.png' $true

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'FanHubPlus') }}</title>
    @vite(['resources/css/app.scss', 'resources/js/app.js'])
    @include('partials.font-links')
    <style>[x-cloak] { display: none !important; }</style>
    @stack('styles')
</head>
<body>
    <div class="d-flex">
        @include('layouts.user.sidebar')

        <div class="flex-grow-1" style="min-height: 100vh;">
            @include('layouts.topbar')

            <main class="p-4">
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if(session('status'))
                    <div class="alert alert-info alert-dismissible fade show" role="alert">
                        {{ session('status') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @isset($header)
                    <div class="mb-4">{{ $header }}</div>
                @endisset

                @yield('content')
            </main>
        </div>
    </div>

    @stack('scripts')
</body>
</html>

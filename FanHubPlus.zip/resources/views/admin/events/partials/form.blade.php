<div class="row">
    <div class="col-lg-8">
        <form action="{{ $action }}" method="POST">
            @csrf
            @method($method)

            <div class="card mb-4 fh-adm-form-card">
                <div class="card-header"><h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Basic') }}</h6></div>
                <div class="card-body">
                    <div class="mb-3">
                        <x-input-label for="title" :value="__('Title')" />
                        <x-text-input id="title" name="title" type="text" class="form-control" :value="old('title', $event?->title)" required />
                        <x-input-error :messages="$errors->get('title')" class="mt-1" />
                    </div>
                    <div class="mb-3">
                        <x-input-label for="description" :value="__('Description')" />
                        <textarea id="description" name="description" rows="4" class="form-control @error('description') is-invalid @enderror">{{ old('description', $event?->description) }}</textarea>
                        <x-input-error :messages="$errors->get('description')" class="mt-1" />
                    </div>
                    <div class="mb-3">
                        <x-input-label for="short_description" :value="__('Short description')" />
                        <textarea id="short_description" name="short_description" maxlength="400" rows="2" class="form-control">{{ old('short_description', $event?->short_description) }}</textarea>
                        <x-input-error :messages="$errors->get('short_description')" class="mt-1" />
                    </div>
                    <div class="mb-3">
                        <x-input-label for="event_type" :value="__('Event type')" />
                        <select name="event_type" id="event_type" class="form-select">
                            <option value="">Not specified</option>
                            @foreach(config('events.types') as $value => $label)<option value="{{ $value }}" @selected(old('event_type', $event?->event_type) === $value)>{{ $label }}</option>@endforeach
                        </select>
                        <x-input-error :messages="$errors->get('event_type')" class="mt-1" />
                    </div>
                    <div class="mb-0">
                        <x-input-label for="category_id" :value="__('Category (required)')" />
                        <select name="category_id" id="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                            <option value="">{{ __('Select category') }}</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" @selected((int) old('category_id', $event?->category_id) === $category->id)>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        <x-input-error :messages="$errors->get('category_id')" class="mt-1" />
                    </div>
                    <div class="mb-0 mt-3">
                        <x-input-label for="content_id" :value="__('Related content (optional)')" />
                        <select name="content_id" id="content_id" class="form-select @error('content_id') is-invalid @enderror"
                            data-event-content-select
                            data-lookup-url-template="{{ route('admin.lookups.contents-by-category', ['category' => '__CAT__']) }}">
                            <option value="">{{ __('General category event / No specific content') }}</option>
                            @foreach (($contents ?? collect()) as $contentItem)
                                <option value="{{ $contentItem->id }}" @selected((int) old('content_id', $event?->content_id) === $contentItem->id)>{{ \Illuminate\Support\Str::limit($contentItem->title, 80) }}</option>
                            @endforeach
                        </select>
                        <p class="text-muted small mt-1">{{ __('Pick a specific content for screenings/launches, or leave as a general category-level event.') }}</p>
                        <x-input-error :messages="$errors->get('content_id')" class="mt-1" />
                    </div>
                </div>
            </div>

            <div class="card mb-4 fh-adm-form-card">
                <div class="card-header"><h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Location') }}</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <x-input-label for="city" :value="__('City')" />
                            <x-text-input id="city" name="city" type="text" class="form-control" :value="old('city', $event?->city)" required />
                            <x-input-error :messages="$errors->get('city')" class="mt-1" />
                        </div>
                        <div class="col-md-4 mb-3">
                            <x-input-label for="venue" :value="__('Venue')" />
                            <x-text-input id="venue" name="venue" type="text" class="form-control" :value="old('venue', $event?->venue)" />
                            <x-input-error :messages="$errors->get('venue')" class="mt-1" />
                        </div>
                        <div class="col-md-4 mb-3">
                            <x-input-label for="address" :value="__('Address')" />
                            <x-text-input id="address" name="address" type="text" class="form-control" :value="old('address', $event?->address)" />
                            <x-input-error :messages="$errors->get('address')" class="mt-1" />
                        </div>
                        <div class="col-md-8 mb-3">
                            <x-input-label for="google_maps_location" :value="__('Google Maps Location Link')" />
                            <x-text-input id="google_maps_location" name="google_maps_location" type="url" class="form-control" :value="old('google_maps_location', $event?->google_maps_location)" placeholder="https://maps.google.com/..." />
                            <small class="text-muted">{{ __('Paste a Google Maps link for this event location. Used for "events nearby" feature.') }}</small>
                            <x-input-error :messages="$errors->get('google_maps_location')" class="mt-1" />
                        </div>
                        <div class="col-md-6 mb-0">
                            <x-input-label for="latitude" :value="__('Latitude')" />
                            <x-text-input id="latitude" name="latitude" type="number" step="0.00000001" min="-90" max="90" class="form-control" :value="old('latitude', $event?->latitude)" />
                            <x-input-error :messages="$errors->get('latitude')" class="mt-1" />
                        </div>
                        <div class="col-md-6 mb-0">
                            <x-input-label for="longitude" :value="__('Longitude')" />
                            <x-text-input id="longitude" name="longitude" type="number" step="0.00000001" min="-180" max="180" class="form-control" :value="old('longitude', $event?->longitude)" />
                            <x-input-error :messages="$errors->get('longitude')" class="mt-1" />
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 fh-adm-form-card">
                <div class="card-header"><h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Schedule') }}</h6></div>
                <div class="card-body">
                    <p class="text-muted small">Dates and times use {{ config('app.timezone') }}.</p>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <x-input-label for="start_at" :value="__('Start')" />
                            <x-text-input id="start_at" name="start_at" type="datetime-local" class="form-control" :value="old('start_at', $event?->start_at?->format('Y-m-d\TH:i'))" required />
                            <x-input-error :messages="$errors->get('start_at')" class="mt-1" />
                        </div>
                        <div class="col-md-6 mb-0">
                            <x-input-label for="end_at" :value="__('End (optional)')" />
                            <x-text-input id="end_at" name="end_at" type="datetime-local" class="form-control" :value="old('end_at', $event?->end_at?->format('Y-m-d\TH:i'))" />
                            <x-input-error :messages="$errors->get('end_at')" class="mt-1" />
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 fh-adm-form-card">
                <div class="card-header"><h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Publishing') }}</h6></div>
                <div class="card-body">
                    <div class="form-check mb-3">
                        <input type="hidden" name="is_featured" value="0">
                        <input type="checkbox" class="form-check-input" name="is_featured" id="is_featured" value="1" @checked(old('is_featured', $event?->is_featured))>
                        <label class="form-check-label" for="is_featured">Featured event</label>
                        <p class="text-muted small">Up to four published upcoming events appear in the Events spotlight, ordered by popularity then date.</p>
                    </div>
                    <div class="mb-3">
                        <x-input-label for="popularity_score" :value="__('Popularity score')" />
                        <input type="number" class="form-control" id="popularity_score" name="popularity_score" min="0" max="1000000" value="{{ old('popularity_score', $event?->popularity_score ?? 0) }}">
                        <x-input-error :messages="$errors->get('popularity_score')" class="mt-1" />
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <x-input-label for="status" :value="__('Status')" />
                            <select name="status" id="status" class="form-select @error('status') is-invalid @enderror" required>
                                @foreach (['draft', 'published', 'cancelled'] as $statusOption)
                                    <option value="{{ $statusOption }}" @selected(old('status', $event?->status ?? 'draft') === $statusOption)>{{ ucfirst($statusOption) }}</option>
                                @endforeach
                            </select>
                            <x-input-error :messages="$errors->get('status')" class="mt-1" />
                        </div>
                        <div class="col-md-4 mb-3">
                            <x-input-label for="ticket_url" :value="__('Ticket URL')" />
                            <x-text-input id="ticket_url" name="ticket_url" type="url" class="form-control" :value="old('ticket_url', $event?->ticket_url)" />
                            <x-input-error :messages="$errors->get('ticket_url')" class="mt-1" />
                        </div>
                        <div class="col-md-4 mb-3">
                            <x-input-label :value="__('Cover media')" />
                            <div class="fh-adm-pick-list fh-adm-pick-list--single">
                                <label class="fh-adm-pick-item">
                                    <input type="radio" name="cover_media_id" value="" @checked((int) old('cover_media_id', $event?->cover_media_id) === 0)>
                                    <div class="fh-adm-pick-item-body">
                                        <div class="fh-adm-pick-icon"><i class="bi bi-x-lg"></i></div>
                                        <div class="min-w-0">
                                            <div class="fh-adm-pick-name">{{ __('None') }}</div>
                                            <div class="fh-adm-pick-meta">{{ __('No cover') }}</div>
                                        </div>
                                        <span class="fh-adm-pick-state">{{ __('Select') }}</span>
                                    </div>
                                </label>
                                @forelse ($images as $image)
                                    <label class="fh-adm-pick-item">
                                        <input type="radio" name="cover_media_id" value="{{ $image->id }}" @checked((int) old('cover_media_id', $event?->cover_media_id) === $image->id)>
                                        <div class="fh-adm-pick-item-body">
                                            <div class="fh-adm-pick-icon"><i class="bi bi-image"></i></div>
                                            <div class="min-w-0">
                                                <div class="fh-adm-pick-name">{{ $image->original_filename }}</div>
                                                <div class="fh-adm-pick-meta">{{ $image->mime_type ?? 'image' }}</div>
                                            </div>
                                            <span class="fh-adm-pick-state">{{ __('Select') }}</span>
                                        </div>
                                    </label>
                                @empty
                                    <div class="fh-adm-tile-meta">{{ __('No images in the media library yet.') }}</div>
                                @endforelse
                            </div>
                            <x-input-error :messages="$errors->get('cover_media_id')" class="mt-1" />
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="hidden" name="gallery_present" value="1">
                        <x-input-label :value="__('Gallery images (up to 12)')" />
                        <div class="fh-adm-pick-list">
                            @forelse ($images as $image)
                                <label class="fh-adm-pick-item">
                                    <input type="checkbox" name="gallery_media_ids[]" value="{{ $image->id }}" @checked(in_array($image->id, old('gallery_media_ids', $event?->galleryMedia->modelKeys() ?? [])))>
                                    <div class="fh-adm-pick-item-body">
                                        <div class="fh-adm-pick-icon"><i class="bi bi-images"></i></div>
                                        <div class="min-w-0">
                                            <div class="fh-adm-pick-name">{{ $image->original_filename }}</div>
                                            <div class="fh-adm-pick-meta">{{ $image->mime_type ?? 'image' }}</div>
                                        </div>
                                        <span class="fh-adm-pick-state">{{ __('Add') }}</span>
                                    </div>
                                </label>
                            @empty
                                <div class="fh-adm-tile-meta">{{ __('No images in the media library yet.') }}</div>
                            @endforelse
                        </div>
                        <x-input-error :messages="$errors->get('gallery_media_ids')" class="mt-1" />
                        <x-input-error :messages="$errors->first('gallery_media_ids.*')" class="mt-1" />
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2 mb-4">
                <a href="{{ route('admin.events.index') }}" class="btn btn-outline-secondary">{{ __('Cancel') }}</a>
                <x-primary-button>{{ $event ? __('Update Event') : __('Create Event') }}</x-primary-button>
            </div>
        </form>
    </div>

    <div class="col-lg-4">
        <div class="card fh-adm-detail-card">
            <div class="card-header"><h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Validation rules') }}</h6></div>
            <div class="card-body">
                <ul class="mb-0" style="font-size: 0.875rem;">
                    <li class="mb-2">{{ __('Start date and time is required.') }}</li>
                    <li class="mb-2">{{ __('End cannot be before start.') }}</li>
                    <li class="mb-2">{{ __('Latitude and longitude must be valid coordinates.') }}</li>
                    <li class="mb-2">{{ __('Category is required; Related content is optional and must belong to the chosen category.') }}</li>
                    <li class="mb-0">{{ __('Cancelled events stay visible to admins.') }}</li>
                </ul>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    var categorySelect = document.getElementById('category_id');
    var contentSelect = document.getElementById('content_id');
    if (!categorySelect || !contentSelect) return;

    var lookupTemplate = contentSelect.getAttribute('data-lookup-url-template') || '';
    var generalOptionHtml = '<option value="">{{ __('General category event / No specific content') }}</option>';

    function escapeAttr(value) {
        return String(value == null ? '' : value).replace(/"/g, '&quot;');
    }

    function setContentOptions(contents) {
        var html = generalOptionHtml;
        contents.forEach(function (c) {
            html += '<option value="' + c.id + '">' + escapeAttr((c.title || '').slice(0, 80)) + '</option>';
        });
        contentSelect.innerHTML = html;
    }

    function reload() {
        var cat = categorySelect.value;
        if (!cat || !lookupTemplate) return;
        var url = lookupTemplate.replace('__CAT__', encodeURIComponent(cat));
        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' } })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (json) {
                if (!json || !Array.isArray(json.contents)) { setContentOptions([]); return; }
                setContentOptions(json.contents);
            })
            .catch(function () { setContentOptions([]); });
    }

    categorySelect.addEventListener('change', function () {
        contentSelect.value = '';
        reload();
    });
});
</script>
@endpush

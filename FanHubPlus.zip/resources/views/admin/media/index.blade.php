﻿@extends('layouts.app')

@section('content')
    <div class="mb-4 fh-adm-page-head">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <h2 class="h4 mb-0 fw-semibold">{{ __('Media Library') }}</h2>
                <p class="text-muted mb-0 mt-1" style="font-size:.8rem;">{{ __('Manage images, videos, audio, and documents. Large movies use chunked upload (up to 512MB).') }}</p>
            </div>
        </div>
    </div>

    <div class="card mb-4 fh-adm-form-card">
        <div class="card-header">
            <h6 class="mb-0 fw-semibold fh-adm-section-title">{{ __('Upload Files') }}</h6>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.media.store') }}" method="POST" enctype="multipart/form-data" id="uploadForm">
                @csrf
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="category_id" class="form-label">{{ __('Category (optional)') }}</label>
                        <select class="form-select @error('category_id') is-invalid @enderror" name="category_id" id="category_id">
                            <option value="">{{ __('General / No category') }}</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" @selected((int) old('category_id') === $category->id)>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        <small class="text-muted">{{ __('Leave empty to keep the file in General (shared) media.') }}</small>
                        @error('category_id')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-8">
                        <label for="alt_text" class="form-label">{{ __('Alt text (applied to all uploaded files)') }}</label>
                        <input type="text" class="form-control @error('alt_text') is-invalid @enderror" name="alt_text" id="alt_text" maxlength="255" value="{{ old('alt_text') }}" placeholder="{{ __('Descriptive text for accessibility') }}">
                        @error('alt_text')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">{{ __('Duration (video/audio only)') }}</label>
                        <div class="row g-2">
                            <div class="col-4">
                                <input type="number" class="form-control @error('duration_hours') is-invalid @enderror" name="duration_hours" id="duration_hours" min="0" max="23" value="{{ old('duration_hours', 0) }}" placeholder="0">
                                <small class="text-muted">{{ __('Hours') }}</small>
                            </div>
                            <div class="col-4">
                                <input type="number" class="form-control @error('duration_minutes') is-invalid @enderror" name="duration_minutes" id="duration_minutes" min="0" max="59" value="{{ old('duration_minutes', 0) }}" placeholder="0">
                                <small class="text-muted">{{ __('Minutes') }}</small>
                            </div>
                            <div class="col-4">
                                <input type="number" class="form-control @error('duration_seconds') is-invalid @enderror" name="duration_seconds" id="duration_seconds" min="0" max="59.99" step="0.01" value="{{ old('duration_seconds', 0) }}" placeholder="0">
                                <small class="text-muted">{{ __('Seconds') }}</small>
                            </div>
                        </div>
                        <small class="text-muted">{{ __('Automatically saved as total seconds.') }}</small>
                        @error('duration_hours')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                        @error('duration_minutes')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                        @error('duration_seconds')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-7">
                        <label class="form-label">{{ __('Select Files') }}</label>
                        <input type="file" class="form-control @error('files') is-invalid @enderror" name="files[]" multiple accept=".jpg,.jpeg,.png,.gif,.webp,.svg,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.mp4,.webm,.ogv,.mov,.avi,.mkv,.wmv,.3gp,.mp3,.wav,.ogg,.m4a,.aac" required>
                        <small class="text-muted">{{ __('Images max 5MB, documents 25MB, video 100MB, movies up to 512MB (auto chunked). Up to 10 files per upload.') }}</small>
                        <div id="fileList" class="mt-2 small text-muted"></div>
                        @error('files')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                        @error('files.*')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div id="uploadProgress" class="d-none mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium">{{ __('Uploading...') }}</span>
                        <button type="button" id="cancelUpload" class="btn btn-sm btn-outline-danger" style="font-size: 0.75rem;">{{ __('Cancel') }}</button>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <div id="progressText" class="text-muted small mt-1 text-end"></div>
                </div>

                <div class="d-flex gap-2 mt-2">
                    <button type="submit" class="btn btn-primary" id="uploadBtn">
                        <i class="bi bi-upload me-1"></i>{{ __('Upload') }}
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4 fh-adm-filter">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.media.index') }}" class="row g-3">
                <div class="col-md-4">
                    <input type="text" class="form-control" name="search" placeholder="{{ __('Search files...') }}" value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="type">
                        <option value="">{{ __('All Types') }}</option>
                        <option value="image" {{ request('type') === 'image' ? 'selected' : '' }}>{{ __('Images') }}</option>
                        <option value="video" {{ request('type') === 'video' ? 'selected' : '' }}>{{ __('Video') }}</option>
                        <option value="audio" {{ request('type') === 'audio' ? 'selected' : '' }}>{{ __('Audio') }}</option>
                        <option value="document" {{ request('type') === 'document' ? 'selected' : '' }}>{{ __('Documents') }}</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="category_id">
                        <option value="">{{ __('All Categories') }}</option>
                        <option value="general" @selected(request('category_id') === 'general')>{{ __('General (no category)') }}</option>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}" @selected(request('category_id') == $category->id)>{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-outline-secondary w-100">
                        <i class="bi bi-search me-1"></i>{{ __('Filter') }}
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card fh-adm-form-card">
        <div class="card-body">
            @forelse ($media as $item)
                @if ($loop->first || ($loop->index % 6 === 0))
                    <div class="row g-3 mb-3">
                @endif

                <div class="col-md-2">
                    <div class="card h-100 border">
                        <div class="card-body p-2 text-center">
                            @if ($item->isImage())
                                @if ($item->url)
                                <img src="{{ $item->url }}" alt="{{ $item->alt_text ?: $item->original_filename }}" class="img-fluid rounded mb-2" style="max-height: 80px; object-fit: cover;">
                                @endif
                            @elseif ($item->isVideo())
                                <i class="bi bi-film text-primary fs-1"></i>
                            @elseif ($item->isAudio())
                                <i class="bi bi-music-note-beamed text-info fs-1"></i>
                            @elseif ($item->mime_type === 'application/pdf')
                                <i class="bi bi-file-earmark-pdf text-danger fs-1"></i>
                            @else
                                <i class="bi bi-file-earmark text-secondary fs-1"></i>
                            @endif
                            <div class="text-truncate" style="font-size: 0.75rem;" title="{{ $item->original_filename }}">{{ $item->original_filename ?: __('Untitled') }}</div>
                            <div class="text-muted" style="font-size: 0.65rem;">{{ $item->size_formatted }} &middot; {{ $item->media_type }}</div>
                            <div class="mt-1">
                                <span class="badge {{ $item->category ? 'bg-primary' : 'bg-secondary' }} text-truncate" style="font-size: 0.6rem; max-width: 100%;">
                                    {{ $item->category?->name ?: __('General') }}
                                </span>
                            </div>
                            @if ($item->isReferenced())
                                <div class="text-warning" style="font-size: 0.65rem;"><i class="bi bi-link-45deg"></i> {{ __('In use') }}</div>
                            @endif
                            @if ($item->status === 'uploading')
                                <div class="text-info" style="font-size: 0.65rem;">
                                    <i class="bi bi-arrow-clockwise"></i> {{ $item->uploaded_chunks }}/{{ $item->total_chunks }} chunks
                                </div>
                            @endif
                        </div>
                        <div class="card-footer bg-transparent p-1 text-center">
                            @if ($item->url)
                                <a href="{{ $item->isAudio() ? route('admin.media.edit', $item) : $item->url }}" class="btn btn-outline-info btn-sm" style="font-size: 0.7rem;" @if (! $item->isAudio()) target="_blank" rel="noopener" @endif title="{{ $item->isAudio() ? __('Listen') : __('View') }}"><i class="bi {{ $item->isAudio() ? 'bi-play-circle' : 'bi-eye' }}"></i></a>
                                <a href="{{ route('admin.media.download', $item) }}" class="btn btn-outline-success btn-sm" style="font-size: 0.7rem;" title="{{ __('Download') }}"><i class="bi bi-download"></i></a>
                            @endif
                            <a href="{{ route('admin.media.edit', $item) }}" class="btn btn-outline-primary btn-sm" style="font-size: 0.7rem;" title="{{ __('Edit') }}"><i class="bi bi-pencil"></i></a>
                            <form action="{{ route('admin.media.destroy', $item) }}" method="POST" class="d-inline" data-confirm="{{ __('Delete this file?') }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-outline-danger btn-sm" style="font-size: 0.7rem;" @if ($item->isReferenced()) disabled title="{{ __('Referenced by other records') }}" @endif><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    </div>
                </div>

                @if ($loop->last || ($loop->index % 6 === 5))
                    </div>
                @endif
            @empty
                <div class="fh-adm-empty">
                    <i class="bi bi-folder"></i>
                    <p>{{ __('No files uploaded yet.') }}</p>
                </div>
            @endforelse
        </div>

        @if ($media->hasPages())
            <div class="card-footer py-3 overflow-auto">
                {{ $media->onEachSide(1)->links('pagination::bootstrap-5') }}
            </div>
        @endif
    </div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    if (!uploadForm) return;

    const fileInput = uploadForm.querySelector('input[type="file"]');
    const uploadBtn = uploadForm.querySelector('button[type="submit"]');
    const progressContainer = document.getElementById('uploadProgress');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const fileList = document.getElementById('fileList');
    const cancelBtn = document.getElementById('cancelUpload');

    let uploadXhr = null;
    let isChunkedUpload = false;
    let uploadMediaId = null;
    let totalChunks = 0;
    let uploadedChunks = 0;
    let chunkSize = 5 * 1024 * 1024;
    let currentFile = null;
    let currentChunkIndex = 0;

    fileInput.addEventListener('change', function() {
        fileList.innerHTML = '';
        Array.from(this.files).forEach((file, index) => {
            const div = document.createElement('div');
            div.className = 'd-flex justify-content-between align-items-center py-1 border-bottom small';
            div.innerHTML = `
                <span class="text-truncate me-2" style="max-width: 200px;">${file.name}</span>
                <span class="text-muted">${formatBytes(file.size)}</span>
            `;
            fileList.appendChild(div);
        });
    });

    uploadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const files = fileInput.files;
        if (files.length === 0) return;

        let needsChunked = false;
        for (let file of files) {
            if (file.size > 100 * 1024 * 1024) {
                needsChunked = true;
                break;
            }
        }

        if (needsChunked && files.length === 1) {
            await uploadChunked(files[0]);
        } else {
            await uploadRegular(files);
        }
    });

    async function uploadRegular(files) {
        const formData = new FormData();
        for (let file of files) {
            formData.append('files[]', file);
        }
        formData.append('alt_text', document.getElementById('alt_text')?.value || '');
        formData.append('category_id', document.getElementById('category_id')?.value || '');
        
        const durationHours = document.getElementById('duration_hours')?.value || 0;
        const durationMinutes = document.getElementById('duration_minutes')?.value || 0;
        const durationSeconds = document.getElementById('duration_seconds')?.value || 0;
        formData.append('duration_hours', durationHours);
        formData.append('duration_minutes', durationMinutes);
        formData.append('duration_seconds', durationSeconds);
        
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

        uploadXhr = new XMLHttpRequest();
        
        uploadXhr.upload.addEventListener('progress', function(e) {
            if (e.lengthComputable) {
                const percent = Math.round((e.loaded / e.total) * 100);
                updateProgress(percent, `${formatBytes(e.loaded)} / ${formatBytes(e.total)}`);
            }
        });

        uploadXhr.addEventListener('load', function() {
            if (uploadXhr.status >= 200 && uploadXhr.status < 300) {
                hideProgress();
                location.reload();
            } else {
                showError('Upload failed: ' + uploadXhr.responseText);
            }
        });

        uploadXhr.addEventListener('error', function() {
            showError('Upload failed. Please try again.');
        });

        uploadXhr.addEventListener('abort', function() {
            hideProgress();
        });

        uploadXhr.open('POST', '{{ route('admin.media.store') }}', true);
        uploadXhr.send(formData);

        showProgress();
    }

    async function uploadChunked(file) {
        const chunkSize = 5 * 1024 * 1024;
        const totalChunks = Math.ceil(file.size / chunkSize);
        
        isChunkedUpload = true;
        totalChunks = totalChunks;
        uploadedChunks = 0;
        currentFile = file;
        currentChunkIndex = 0;

        const initFormData = new FormData();
        initFormData.append('filename', file.name);
        initFormData.append('total_size', file.size);
        initFormData.append('total_chunks', totalChunks);
        initFormData.append('chunk_size', chunkSize);
        initFormData.append('mime_type', file.type);
        initFormData.append('alt_text', document.getElementById('alt_text')?.value || '');
        initFormData.append('category_id', document.getElementById('category_id')?.value || '');
        initFormData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

        try {
            const initResponse = await fetch('{{ route('admin.media.chunk.init') }}', {
                method: 'POST',
                body: initFormData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json',
                },
            });

            const initData = await initResponse.json();
            if (!initResponse.ok) throw new Error(initData.message || 'Failed to initialize upload');
            
            uploadMediaId = initData.media_id;
            showProgress();

            for (let i = 0; i < totalChunks; i++) {
                if (uploadXhr && uploadXhr.readyState === XMLHttpRequest.OPENED) {
                    if (cancelBtn?.dataset.cancelled === 'true') break;
                }

                currentChunkIndex = i;
                const start = i * chunkSize;
                const end = Math.min(start + chunkSize, file.size);
                const chunk = file.slice(start, end);

                const chunkFormData = new FormData();
                chunkFormData.append('media_id', uploadMediaId);
                chunkFormData.append('chunk_index', i);
                chunkFormData.append('chunk', chunk);
                chunkFormData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

                const chunkResponse = await fetch('{{ route('admin.media.chunk.upload') }}', {
                    method: 'POST',
                    body: chunkFormData,
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json',
                    },
                });

                const chunkData = await chunkResponse.json();
                if (!chunkResponse.ok) throw new Error(chunkData.message || `Chunk ${i} failed`);

                uploadedChunks = chunkData.uploaded_chunks;
                const progress = chunkData.progress;
                updateProgress(progress, `Chunk ${i + 1} / ${totalChunks} (${formatBytes(i * chunkSize)} / ${formatBytes(file.size)})`);
            }

            const durationHours = document.getElementById('duration_hours')?.value || 0;
            const durationMinutes = document.getElementById('duration_minutes')?.value || 0;
            const durationSeconds = document.getElementById('duration_seconds')?.value || 0;

            const completeFormData = new FormData();
            completeFormData.append('media_id', uploadMediaId);
            completeFormData.append('duration_hours', durationHours);
            completeFormData.append('duration_minutes', durationMinutes);
            completeFormData.append('duration_seconds', durationSeconds);
            completeFormData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

            const completeResponse = await fetch('{{ route('admin.media.chunk.complete') }}', {
                method: 'POST',
                body: completeFormData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json',
                },
            });

            const completeData = await completeResponse.json();
            if (!completeResponse.ok) throw new Error(completeData.message || 'Failed to complete upload');

            hideProgress();
            location.reload();

        } catch (error) {
            showError(error.message);
            if (uploadMediaId) {
                await fetch('{{ route('admin.media.chunk.cancel') }}', {
                    method: 'POST',
                    body: new URLSearchParams({ media_id: uploadMediaId, _token: document.querySelector('meta[name="csrf-token"]').content }),
                });
            }
        }
    }

    cancelBtn?.addEventListener('click', function() {
        if (uploadXhr) {
            uploadXhr.abort();
        }
        if (isChunkedUpload && uploadMediaId) {
            this.dataset.cancelled = 'true';
            fetch('{{ route('admin.media.chunk.cancel') }}', {
                method: 'POST',
                body: new URLSearchParams({ media_id: uploadMediaId, _token: document.querySelector('meta[name="csrf-token"]').content }),
            });
        }
        hideProgress();
    });

    function showProgress() {
        progressContainer?.classList.remove('d-none');
        uploadBtn?.setAttribute('disabled', 'disabled');
        fileInput?.setAttribute('disabled', 'disabled');
        updateProgress(0, 'Starting...');
    }

    function hideProgress() {
        progressContainer?.classList.add('d-none');
        uploadBtn?.removeAttribute('disabled');
        fileInput?.removeAttribute('disabled');
        cancelBtn?.dataset.cancelled = 'false';
    }

    function updateProgress(percent, text = '') {
        progressBar?.style.setProperty('width', percent + '%');
        progressBar?.setAttribute('aria-valuenow', percent);
        progressText?.textContent = text || `${Math.round(percent)}%`;
    }

    function showError(message) {
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger alert-dismissible fade show mt-3';
        alert.innerHTML = `${message} <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
        uploadForm.insertAdjacentElement('afterbegin', alert);
        hideProgress();
    }

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
});
</script>
@endpush

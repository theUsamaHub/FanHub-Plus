<p class="merch-toast" data-bookmark-status role="status" aria-live="polite" hidden></p>
<?php if(auth()->guard()->guest()): ?>
<dialog class="merch-login-dialog" data-merch-login aria-labelledby="merch-login-title">
    <button type="button" class="merch-dialog-close" data-close-merch-login aria-label="Close login prompt"><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'heart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
    <h2 id="merch-login-title">Keep your favourites close.</h2>
    <p>Log in to save merchandise to your bookmarks and find it again anytime.</p>
    <a class="join-button" href="<?php echo e(route('login')); ?>">Log in <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></a>
    <a class="merch-dialog-register" href="<?php echo e(route('register')); ?>">New here? Join FanHub Plus</a>
</dialog>
<?php endif; ?>
<?php /**PATH D:\FanHubPlus\resources\views/partials/merchandise-feedback.blade.php ENDPATH**/ ?>
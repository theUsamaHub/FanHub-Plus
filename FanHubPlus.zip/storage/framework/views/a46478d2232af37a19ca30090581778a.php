<?php $__env->startSection('title', 'Contact Us | Fan Hub Plus'); ?>
<?php $__env->startSection('main-class', 'contact-page'); ?>
<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/pages/contact.css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="contact-page" data-contact-page>
    <section class="contact-hero" data-contact-hero>
        <div class="contact-hero__bg" aria-hidden="true">
            <div class="contact-hero__gradient"></div>
            <div class="contact-hero__particles" data-particles></div>
        </div>
        <div class="contact-hero__content">
            <p class="contact-kicker" data-animate="fade-up" data-delay="0">GET IN TOUCH</p>
            <h1 data-animate="fade-up" data-delay="100">Let's start a <span class="contact-highlight">conversation.</span></h1>
            <p class="contact-lead" data-animate="fade-up" data-delay="200">Have a question, suggestion, or just want to say hello? We'd love to hear from you. Our team reads every message personally.</p>
        </div>
    </section>

    <section class="contact-form-section" data-contact-form-section>
        <div class="contact-container">
            <div class="contact-grid">
                <div class="contact-form-wrapper" data-contact-form-wrapper>
                    <div class="contact-form-card" data-animate="slide-up" data-delay="100">
                        <div class="contact-form-header">
                            <p class="contact-form-kicker">SEND A MESSAGE</p>
                            <h2>We're all ears</h2>
                            <p>Fill out the form and we'll get back to you within 24 hours.</p>
                        </div>

                        <?php if(session('success')): ?>
                            <div class="contact-alert contact-alert--success" data-animate="scale-in" role="alert">
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'check','class' => 'contact-alert-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','class' => 'contact-alert-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                <span><?php echo e(session('success')); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="contact-alert contact-alert--error" data-animate="scale-in" role="alert">
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'close','class' => 'contact-alert-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close','class' => 'contact-alert-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                <span><?php echo e(session('error')); ?></span>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('contact.store')); ?>" method="POST" class="contact-form" data-contact-form>
                            <?php echo csrf_field(); ?>

                            <div class="contact-form-row">
                                <div class="contact-field" data-animate="fade-up" data-delay="100">
                                    <label for="name" class="contact-field__label">
                                        <span>Your Name</span>
                                        <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'user','class' => 'contact-field-icon','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'contact-field-icon','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                    </label>
                                    <input
                                        type="text"
                                        id="name"
                                        name="name"
                                        class="contact-field__input <?php echo e($errors->has('name') ? 'contact-field__input--error' : ''); ?>"
                                        value="<?php echo e(old('name')); ?>"
                                        required
                                        maxlength="255"
                                        autocomplete="name"
                                        placeholder="Enter your name"
                                        aria-describedby="<?php echo e($errors->has('name') ? 'name-error' : 'name-hint'); ?>"
                                    >
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p id="name-error" class="contact-field__error" role="alert"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <span id="name-hint" class="contact-field__hint">How should we address you?</span>
                                </div>

                                <div class="contact-field" data-animate="fade-up" data-delay="150">
                                    <label for="email" class="contact-field__label">
                                        <span>Email Address</span>
                                        <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'mail','class' => 'contact-field-icon','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'mail','class' => 'contact-field-icon','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                    </label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        class="contact-field__input <?php echo e($errors->has('email') ? 'contact-field__input--error' : ''); ?>"
                                        value="<?php echo e(old('email')); ?>"
                                        required
                                        maxlength="255"
                                        autocomplete="email"
                                        placeholder="you@example.com"
                                        aria-describedby="<?php echo e($errors->has('email') ? 'email-error' : 'email-hint'); ?>"
                                    >
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p id="email-error" class="contact-field__error" role="alert"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <span id="email-hint" class="contact-field__hint">We'll reply here</span>
                                </div>
                            </div>

                            <div class="contact-field" data-animate="fade-up" data-delay="200">
                                <label for="subject" class="contact-field__label">
                                    <span>Subject</span>
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'tag','class' => 'contact-field-icon','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'tag','class' => 'contact-field-icon','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </label>
                                <select
                                    id="subject"
                                    name="subject"
                                    class="contact-field__select <?php echo e($errors->has('subject') ? 'contact-field__select--error' : ''); ?>"
                                    aria-describedby="<?php echo e($errors->has('subject') ? 'subject-error' : 'subject-hint'); ?>"
                                >
                                    <option value="" disabled <?php echo e(!old('subject') ? 'selected' : ''); ?>>What's this about?</option>
                                    <option value="general" <?php echo e(old('subject') === 'general' ? 'selected' : ''); ?>>General Inquiry</option>
                                    <option value="partnership" <?php echo e(old('subject') === 'partnership' ? 'selected' : ''); ?>>Partnership & Business</option>
                                    <option value="press" <?php echo e(old('subject') === 'press' ? 'selected' : ''); ?>>Press & Media</option>
                                    <option value="technical" <?php echo e(old('subject') === 'technical' ? 'selected' : ''); ?>>Technical Support</option>
                                    <option value="feedback" <?php echo e(old('subject') === 'feedback' ? 'selected' : ''); ?>>Feedback & Suggestions</option>
                                    <option value="other" <?php echo e(old('subject') === 'other' ? 'selected' : ''); ?>>Something Else</option>
                                </select>
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p id="subject-error" class="contact-field__error" role="alert"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <span id="subject-hint" class="contact-field__hint">Helps us route your message faster</span>
                            </div>

                            <div class="contact-field" data-animate="fade-up" data-delay="250">
                                <label for="message" class="contact-field__label">
                                    <span>Your Message</span>
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'message-square','class' => 'contact-field-icon','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'message-square','class' => 'contact-field-icon','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </label>
                                <textarea
                                    id="message"
                                    name="message"
                                    class="contact-field__textarea <?php echo e($errors->has('message') ? 'contact-field__textarea--error' : ''); ?>"
                                    required
                                    maxlength="5000"
                                    minlength="10"
                                    rows="6"
                                    placeholder="Tell us what's on your mind..."
                                    aria-describedby="<?php echo e($errors->has('message') ? 'message-error' : 'message-hint'); ?>"
                                ><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p id="message-error" class="contact-field__error" role="alert"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="contact-field__footer">
                                    <span id="message-hint" class="contact-field__hint">
                                        <span data-char-count>0</span>/5000 characters
                                    </span>
                                    <span class="contact-field__hint">Min 10 characters</span>
                                </div>
                            </div>

                            <div class="contact-honeypot" aria-hidden="true">
                                <label for="website">Don't fill this out if you're human</label>
                                <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
                            </div>

                            <button
                                type="submit"
                                class="contact-submit"
                                data-contact-submit
                                data-animate="fade-up"
                                data-delay="300"
                            >
                                <span class="contact-submit__text">
                                    <span class="contact-submit__label">Send Message</span>
                                    <span class="contact-submit__sending" hidden>Sending...</span>
                                </span>
                                <span class="contact-submit__icon" aria-hidden="true">
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'send']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'send']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </span>
                                <span class="contact-submit__ripple"></span>
                                <span class="contact-submit__progress" aria-hidden="true"></span>
                            </button>

                            <p class="contact-form__privacy" data-animate="fade-up" data-delay="400">
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'shield','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                By submitting, you agree to our <a href="<?php echo e(route('public.section', 'privacy')); ?>">Privacy Policy</a>. We never share your data.
                            </p>
                        </form>
                    </div>
                </div>

                <div class="contact-info-wrapper" data-contact-info-wrapper>
                    <div class="contact-info-card" data-animate="slide-up" data-delay="200">
                        <div class="contact-info-header">
                            <p class="contact-info-kicker">OTHER WAYS TO REACH US</p>
                            <h2>Connect directly</h2>
                        </div>

                        <div class="contact-methods">
                            <a href="mailto:hello@fanhubplus.com" class="contact-method" data-animate="fade-right" data-delay="100">
                                <div class="contact-method__icon">
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'mail']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'mail']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </div>
                                <div class="contact-method__content">
                                    <h3>Email Us</h3>
                                    <p>hello@fanhubplus.com</p>
                                    <span class="contact-method__meta">Replies within 24h</span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow-right','class' => 'contact-method__arrow','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'contact-method__arrow','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                            </a>

                            <a href="https://discord.gg/fanhubplus" target="_blank" rel="noopener noreferrer" class="contact-method" data-animate="fade-right" data-delay="150">
                                <div class="contact-method__icon contact-method__icon--discord">
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'discord']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'discord']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </div>
                                <div class="contact-method__content">
                                    <h3>Discord Community</h3>
                                    <p>Join the conversation</p>
                                    <span class="contact-method__meta">Active 24/7</span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow-right','class' => 'contact-method__arrow','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'contact-method__arrow','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                            </a>

                            <a href="https://twitter.com/fanhubplus" target="_blank" rel="noopener noreferrer" class="contact-method" data-animate="fade-right" data-delay="200">
                                <div class="contact-method__icon contact-method__icon--twitter">
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </div>
                                <div class="contact-method__content">
                                    <h3>Twitter / X</h3>
                                    <p>@fanhubplus</p>
                                    <span class="contact-method__meta">Quick questions</span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow-right','class' => 'contact-method__arrow','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'contact-method__arrow','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                            </a>

                            <div class="contact-method" data-animate="fade-right" data-delay="250">
                                <div class="contact-method__icon contact-method__icon--location">
                                    <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'map-pin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'map-pin']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                                </div>
                                <div class="contact-method__content">
                                    <h3>Office</h3>
                                    <p>FanHub Plus HQ</p>
                                    <span class="contact-method__meta">Tokyo, Japan</span>
                                </div>
                                <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow-right','class' => 'contact-method__arrow','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'contact-method__arrow','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                            </div>
                        </div>

                    </div>

                    <div class="contact-faq-card" data-animate="slide-up" data-delay="300">
                        <h3>Quick Answers</h3>
                        <div class="contact-faq-list">
                            <details class="contact-faq-item">
                                <summary>How do I report a bug?</summary>
                                <p>Use the form above and select "Technical Support" as the subject. Include your browser, device, and steps to reproduce.</p>
                            </details>
                            <details class="contact-faq-item">
                                <summary>Can I suggest a new feature?</summary>
                                <p>Absolutely! Select "Feedback & Suggestions" - we read every idea and many features come from community requests.</p>
                            </details>
                            <details class="contact-faq-item">
                                <summary>Business or partnership inquiries?</summary>
                                <p>Select "Partnership & Business" and our partnerships team will review within 2 business days.</p>
                            </details>
                            <details class="contact-faq-item">
                                <summary>Press and media requests</summary>
                                <p>Select "Press & Media" for press kits, interview requests, and media assets.</p>
                            </details>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="contact-toast" id="contact-toast" role="status" aria-live="polite" hidden>
        <div class="contact-toast__content">
            <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'check-circle','class' => 'contact-toast__icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','class' => 'contact-toast__icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
            <span class="contact-toast__message">Message sent successfully!</span>
        </div>
        <button class="contact-toast__close" aria-label="Dismiss">
            <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
        </button>
        <div class="contact-toast__progress"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/modules/contact-page.js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FanHubPlus\resources\views/public/contact.blade.php ENDPATH**/ ?>
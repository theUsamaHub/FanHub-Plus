<?php
    $groups = [
        'Explore' => ['Fandoms' => route('public.explore'), 'Characters' => route('public.section', 'characters'), 'Upcoming' => route('public.section', 'upcoming'), 'Merchandise' => route('public.section', 'merchandise'), 'Events' => route('events.index'), 'Contact' => route('public.contact')],
        'Your space' => auth()->check() ? ['Dashboard' => route('public.account', 'dashboard'), 'Bookmarks' => route('public.account', 'bookmarks'), 'Profile' => route('profile.edit'), 'Feedback' => route('user.feedback')] : ['Login' => route('login'), 'Create account' => route('register'), 'Bookmarks' => route('public.account', 'bookmarks')],
        'FanHub Plus' => ['Feedback' => route('public.section', 'feedback'), 'Contact' => route('public.contact'), 'Privacy' => route('public.section', 'privacy'), 'Terms' => route('public.section', 'terms'), 'Sitemap' => route('public.sitemap')],
    ];
    $linkIcons = ['Fandoms' => 'compass', 'Characters' => 'people', 'Upcoming' => 'calendar-event', 'Merchandise' => 'bag', 'Events' => 'ticket-perforated', 'Contact' => 'envelope', 'Dashboard' => 'grid', 'Bookmarks' => 'bookmark', 'Profile' => 'person-circle', 'Feedback' => 'chat-square-text', 'Login' => 'box-arrow-in-right', 'Create account' => 'person-plus', 'Privacy' => 'shield-check', 'Terms' => 'file-earmark-text', 'Sitemap' => 'diagram-3'];
?>
<footer class="fh-footer-lite">
    <div class="fh-footer-lite__main">
        <div class="fh-footer-lite__brand">
            <?php if (isset($component)) { $__componentOriginalf44daa962417a920c99bb0c0825b0f00 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf44daa962417a920c99bb0c0825b0f00 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-brand','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf44daa962417a920c99bb0c0825b0f00)): ?>
<?php $attributes = $__attributesOriginalf44daa962417a920c99bb0c0825b0f00; ?>
<?php unset($__attributesOriginalf44daa962417a920c99bb0c0825b0f00); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf44daa962417a920c99bb0c0825b0f00)): ?>
<?php $component = $__componentOriginalf44daa962417a920c99bb0c0825b0f00; ?>
<?php unset($__componentOriginalf44daa962417a920c99bb0c0825b0f00); ?>
<?php endif; ?>
            <p>Your favorite worlds. Your kind of people.<br>Find your next obsession with FanHub Plus.</p>
            <a class="fh-footer-lite__explore" href="<?php echo e(route('public.explore')); ?>">Find your fandom <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'arrow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></a>
        </div>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $links): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <nav aria-label="Footer <?php echo e($title); ?>">
                <h2><?php echo e($title); ?></h2>
                <ul><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $href): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><a href="<?php echo e($href); ?>"><i class="bi bi-<?php echo e($linkIcons[$label]); ?>" aria-hidden="true"></i><span><?php echo e($label); ?></span></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </nav>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="fh-footer-lite__news">
            <div class="fh-footer-lite__news-copy">
                <h2>Newsletter</h2>
                <p>New stories, events and drops — straight to your inbox.</p>
            </div>
            <form method="POST" action="<?php echo e(route('public.subscribe')); ?>" class="fh-footer-lite__news-form">
                <?php echo csrf_field(); ?>
                <div class="fh-footer-lite__email-field">
                    <label for="footer_subscribe_email">Email address</label>
                    <div class="fh-footer-lite__email-input"><i class="bi bi-envelope" aria-hidden="true"></i><input id="footer_subscribe_email" type="email" name="email" autocomplete="email" placeholder="you@example.com" required value="<?php echo e(old('email')); ?>" <?php $__errorArgs = ['email', 'subscribe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" aria-describedby="footer-subscribe-error" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>></div>
                </div>
                <button type="submit"><?php echo e(__('Subscribe')); ?> <i class="bi bi-arrow-right" aria-hidden="true"></i></button>
            </form>
            <?php $__errorArgs = ['email', 'subscribe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p id="footer-subscribe-error" class="fh-footer-lite__news-msg fh-footer-lite__news-msg--error" role="alert"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(session('success')): ?>
                <p class="fh-footer-lite__news-msg"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <div class="fh-footer-lite__bottom">
        <p>&copy; <?php echo e(date('Y')); ?> FanHub Plus. All rights reserved.</p>
        <div class="fh-socials" aria-label="Social media">
            <?php $__currentLoopData = ['discord' => 'Discord', 'twitter-x' => 'X', 'instagram' => 'Instagram', 'youtube' => 'YouTube', 'tiktok' => 'TikTok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(config('socials.'.$icon)): ?><a href="<?php echo e(config('socials.'.$icon)); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($label); ?>"><i class="bi bi-<?php echo e($icon); ?>" aria-hidden="true"></i></a><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="#main-content" class="fh-footer-top">Back to top &uarr;</a>
    </div>
</footer>
<?php /**PATH D:\FanHubPlus\resources\views/components/footer.blade.php ENDPATH**/ ?>
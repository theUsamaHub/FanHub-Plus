<header class="fh-header" data-site-header>
    <nav class="fh-nav" aria-label="Main navigation">
        <?php if (isset($component)) { $__componentOriginalf44daa962417a920c99bb0c0825b0f00 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf44daa962417a920c99bb0c0825b0f00 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-brand','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf44daa962417a920c99bb0c0825b0f00)): ?>
<?php $attributes = $__attributesOriginalf44daa962417a920c99bb0c0825b0f00; ?>
<?php unset($__attributesOriginalf44daa962417a920c99bb0c0825b0f00); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf44daa962417a920c99bb0c0825b0f00)): ?>
<?php $component = $__componentOriginalf44daa962417a920c99bb0c0825b0f00; ?>
<?php unset($__componentOriginalf44daa962417a920c99bb0c0825b0f00); ?>
<?php endif; ?>
        <button class="fh-icon-button fh-mobile-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="site-navigation" data-mobile-toggle><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
        <div class="fh-nav-links" id="site-navigation" data-navigation>
            <a class="fh-nav-link <?php echo e(request()->routeIs('home') ? 'is-active' : ''); ?>" href="<?php echo e(route('home')); ?>" <?php if(request()->routeIs('home')): ?> aria-current="page" <?php endif; ?>>Home</a>
            <div class="fh-fandoms" data-fandoms>
                <button class="fh-nav-link fh-fandom-trigger <?php echo e(request()->routeIs('public.explore') ? 'is-active' : ''); ?>" type="button" aria-expanded="false" aria-controls="fandom-menu" data-fandom-toggle>Fandoms <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'chevron']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
                <div class="fh-mega" id="fandom-menu" data-fandom-menu hidden>
                    <div class="fh-mega-heading"><span>EXPLORE FANDOMS</span><a href="<?php echo e(route('public.explore')); ?>">View all &rarr;</a></div>
                    <div class="fh-fandom-grid">
                    <?php $__currentLoopData = config('fandoms'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $fandom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="fh-fandom-card fh-fandom-card--<?php echo e($slug); ?>" href="<?php echo e(route('public.explore', ['category' => $slug])); ?>">
                            <?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => $fandom['icon']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fandom['icon'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?><span><?php echo e($fandom['name']); ?></span><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'next']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'next']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = ['characters' => 'Characters', 'upcoming' => 'Upcoming', 'merchandise' => 'Merchandise']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="fh-nav-link <?php echo e(request()->is('discover/'.$slug) ? 'is-active' : ''); ?>" href="<?php echo e(route('public.section', $slug)); ?>"><?php echo e($label); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="fh-nav-link <?php echo e(request()->routeIs('events.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('events.index')); ?>" <?php if(request()->routeIs('events.*')): ?> aria-current="page" <?php endif; ?>>Events</a>
            <a class="fh-nav-link <?php echo e(request()->routeIs('public.contact') ? 'is-active' : ''); ?>" href="<?php echo e(route('public.contact')); ?>" <?php if(request()->routeIs('public.contact')): ?> aria-current="page" <?php endif; ?>>Contact</a>
        </div>
        <div class="fh-nav-actions">
            <button class="fh-icon-button fh-search-toggle" type="button" aria-label="Search Fan Hub Plus" data-search-open><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?><span>Find your fandom...</span></button>
            <span class="fh-action-divider" aria-hidden="true"></span>
            <button class="fh-theme-toggle" type="button" role="switch" aria-checked="true" aria-label="Dark mode" data-theme-toggle><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'sun']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sun']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
            <?php if(auth()->guard()->check()): ?>
                <div class="fh-account" data-account>
                    <button class="fh-login fh-avatar-button" type="button" aria-expanded="false" aria-controls="account-menu" aria-label="Open account menu" data-account-toggle><?php if (isset($component)) { $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-avatar','data' => ['user' => auth()->user(),'class' => 'fh-avatar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(auth()->user()),'class' => 'fh-avatar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $attributes = $__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__attributesOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e)): ?>
<?php $component = $__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e; ?>
<?php unset($__componentOriginalaa6ddd3b8ee0acee5a2d1d7ac5c7e40e); ?>
<?php endif; ?><span class="fh-account-name"><?php echo e(auth()->user()->name); ?></span><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'chevron']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
                    <div class="fh-account-menu" id="account-menu" hidden>
                        <p>Welcome, <?php echo e(auth()->user()->name); ?></p>
                        <a href="<?php echo e(route('public.account', 'dashboard')); ?>">My Dashboard</a>
                        <a href="<?php echo e(route('public.account', 'bookmarks')); ?>">Bookmarks</a>
                        <a href="<?php echo e(route('user.favorites')); ?>">Favorite Fandoms</a>
                        <a href="<?php echo e(route('user.activity')); ?>">Recent Activity</a>
                        <a href="<?php echo e(route('user.submissions')); ?>">My Submissions</a>
                        <a href="<?php echo e(route('profile.edit')); ?>">Profile</a>
                        <a href="<?php echo e(route('user.feedback')); ?>">Feedback</a>
                        <a href="<?php echo e(route('public.account', 'submit-content')); ?>">Submit Content</a>
                        <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Logout</button></form>
                    </div>
                </div>
            <?php else: ?>
                <a class="fh-login" href="<?php echo e(route('login')); ?>" aria-label="Login or sign up"><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'user']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?><span>Login / Register</span></a>
            <?php endif; ?>
        </div>
    </nav>
</header>
<dialog class="fh-search-dialog" data-search-dialog aria-labelledby="search-title">
    <button class="fh-icon-button fh-dialog-close" type="button" aria-label="Close search" data-search-close><?php if (isset($component)) { $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-icon','data' => ['name' => 'close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $attributes = $__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__attributesOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0)): ?>
<?php $component = $__componentOriginaldb1036454354fceeb05bdd1a7f850eb0; ?>
<?php unset($__componentOriginaldb1036454354fceeb05bdd1a7f850eb0); ?>
<?php endif; ?></button>
    <h2 id="search-title">Find your universe</h2>
    <p>Search stories across all eight fandoms.</p>
    <form action="<?php echo e(route('public.explore')); ?>" method="GET" role="search">
        <label for="site-search">Search Fan Hub Plus</label>
        <div class="fh-search-field"><input id="site-search" name="q" type="search" maxlength="120" placeholder="Anime, games, stories..." required><button type="submit" class="fh-button">Search</button></div>
    </form>
    <?php if(auth()->guard()->guest()): ?> <p class="fh-search-join">New here? <a href="<?php echo e(route('register')); ?>">Join FanHub+</a></p> <?php endif; ?>
</dialog>
<?php /**PATH D:\FanHubPlus\resources\views/components/navbar.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<svg <?php echo e($attributes->class('fh-icon')); ?> viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <?php switch($name):
        case ('mail'): ?> <rect x="3" y="6" width="26" height="20" rx="3"/><path d="m4 8 12 10L28 8"/> <?php break; ?>
        <?php case ('map-pin'): ?> <path d="M26 13c0 8-10 17-10 17S6 21 6 13a10 10 0 0 1 20 0Z"/><circle cx="16" cy="13" r="3.5"/> <?php break; ?>
        <?php case ('shield'): ?> <path d="m16 3 11 4v9c0 7-11 13-11 13S5 23 5 16V7L16 3Z"/><path d="m11 16 3 3 7-7"/> <?php break; ?>
        <?php case ('arrow-right'): ?> <path d="M3 16h25m-8-8 8 8-8 8"/> <?php break; ?>
        <?php case ('x'): ?> <path fill="currentColor" stroke="none" transform="translate(4 4)" d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.64 7.584H.47l8.6-9.835L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/> <?php break; ?>
        <?php case ('discord'): ?> <path fill="currentColor" stroke="none" transform="translate(4 4)" d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25A19.736 19.736 0 0 0 3.675 4.37C.533 9.046-.32 13.58.099 18.057a19.9 19.9 0 0 0 5.994 3.03c.483-.66.914-1.36 1.285-2.096a12.8 12.8 0 0 1-2.024-.983l.496-.389c3.9 1.814 8.13 1.814 11.985 0l.496.389a12.8 12.8 0 0 1-2.024.983c.371.736.802 1.436 1.285 2.096a19.9 19.9 0 0 0 5.994-3.03c.5-5.18-.854-9.674-3.269-13.687ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419s.974-2.418 2.157-2.418 2.157 1.084 2.157 2.418- .974 2.419-2.157 2.419Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419s.974-2.418 2.157-2.418 2.146 1.084 2.146 2.418-.963 2.419-2.146 2.419Z"/> <?php break; ?>
        <?php case ('heart'): ?> <path d="M16 28 4 16C-3 8 8-1 16 8 24-1 35 8 28 16Z"/> <?php break; ?>
        <?php case ('people'): ?> <circle cx="16" cy="9" r="5"/><circle cx="5" cy="12" r="3"/><circle cx="27" cy="12" r="3"/><path d="M8 28v-6a8 8 0 0 1 16 0v6ZM2 25v-6m28 6v-6"/> <?php break; ?>
        <?php case ('chat'): ?> <path d="M28 15a12 12 0 0 1-17 11L3 29l3-8A12 12 0 1 1 28 15Z"/><path d="M10 15h.1m6 0h.1m6 0h.1" stroke-width="3"/> <?php break; ?>
        <?php case ('arrow'): ?> <path d="M3 16h25m-8-8 8 8-8 8"/> <?php break; ?>
        <?php case ('next'): ?> <path d="m12 6 10 10-10 10"/> <?php break; ?>
        <?php case ('clock'): ?> <circle cx="16" cy="16" r="12"/><path d="M16 8v8l5 3"/> <?php break; ?>
        <?php case ('bag'): ?> <path d="M6 10h20l2 19H4l2-19Z"/><path d="M11 13V7a5 5 0 0 1 10 0v6"/> <?php break; ?>
        <?php case ('crown'): ?> <path d="m3 8 7 6 6-12 6 12 7-6-3 17H6L3 8Z"/><path d="M7 27h18l-9 4-9-4" stroke="#219eff"/> <?php break; ?>
        <?php case ('search'): ?> <circle cx="14" cy="14" r="9"/><path d="m21 21 7 7"/> <?php break; ?>
        <?php case ('bell'): ?> <path d="M7 13a9 9 0 0 1 18 0c0 10 3 10 3 12H4c0-2 3-2 3-12Z"/><path d="M13 29h6M16 2v2"/> <?php break; ?>
        <?php case ('sun'): ?> <circle cx="16" cy="16" r="6"/><path d="M16 2v4m0 20v4M2 16h4m20 0h4M6 6l3 3m14 14 3 3M6 26l3-3M23 9l3-3"/> <?php break; ?>
        <?php case ('moon'): ?> <path d="M23 4A12 12 0 1 1 8 23 12 12 0 0 0 23 4Z" fill="currentColor"/> <?php break; ?>
        <?php case ('user'): ?> <circle cx="16" cy="10" r="6"/><path d="M4 29v-3a12 12 0 0 1 24 0v3Z"/> <?php break; ?>
        <?php case ('menu'): ?> <path d="M5 8h22M5 16h22M5 24h22"/> <?php break; ?>
        <?php case ('close'): ?> <path d="m8 8 16 16M24 8 8 24"/> <?php break; ?>
        <?php case ('chevron'): ?> <path d="m8 12 8 8 8-8"/> <?php break; ?>
        <?php case ('torii'): ?> <path d="M3 5q13 4 26 0M4 11h24M9 8v21M23 8v21M16 7v4M7 18h18"/> <?php break; ?>
        <?php case ('controller'): ?> <path d="M10 7h12c4 0 5 5 7 15 1 5-3 7-6 3l-4-5h-6l-4 5c-3 4-7 2-6-3C5 12 6 7 10 7Z"/><path d="M8 13h6m-3-3v6m10-4h.1m4 4h.1M13 7l1-3h4l1 3"/> <?php break; ?>
        <?php case ('film'): ?> <path d="m16 2 4 4 6 1 1 6 3 3-3 4-1 6-6 1-4 3-4-3-6-1-1-6-3-4 3-3 1-6 6-1Z"/><circle cx="16" cy="16" r="6"/> <?php break; ?>
        <?php case ('tv'): ?> <rect x="3" y="9" width="26" height="21" rx="2"/><path d="m10 2 6 7 6-7M7 14h14v11H7zM25 15v2m0 5v2"/> <?php break; ?>
        <?php case ('gem'): ?> <path d="m2 11 7-8h14l7 8-14 19L2 11Zm0 0h28M9 3l7 27L23 3M9 3l7 8 7-8"/> <?php break; ?>
        <?php case ('mask'): ?> <path d="M2 12c6-5 9-1 14-1s8-4 14 1c1 10-10 15-14 6C12 27 1 22 2 12Z"/><path d="M7 14h4v3H7zm14 0h4v3h-4zM7 6l9-3 9 3"/> <?php break; ?>
        <?php case ('book'): ?> <path d="M16 7C11 2 6 3 3 5v24c4-3 9-3 13 0 4-3 9-3 13 0V5c-3-2-8-3-13 2v22M7 10h4m-4 5h4m-4 5h4m10-10h4m-4 5h4m-4 5h4"/> <?php break; ?>
        <?php case ('hanger'): ?> <path d="M13 7a3 3 0 1 1 3 3v5L3 25c-1 1-1 3 1 3h24c2 0 2-2 1-3L16 15"/> <?php break; ?>
        <?php case ('compass'): ?> <circle cx="16" cy="16" r="14"/><path d="m22 9-4 11-9 4 4-11 9-4Z"/><path d="m13 13 5 7"/> <?php break; ?>
        <?php case ('play'): ?> <path d="m8 3 21 13L8 29V3Z"/> <?php break; ?>
        <?php case ('settings'): ?> <path d="m12 3 1 4h6l1-4 5 3-2 4 3 5 4 1v5l-4 1-3 5 2 3-5 2-1-4h-6l-1 4-5-2 2-3-3-5-4-1v-5l4-1 3-5-2-4 5-3Z" transform="translate(1 -2) scale(.95)"/><circle cx="16" cy="16" r="5"/> <?php break; ?>
    <?php endswitch; ?>
</svg>
<?php /**PATH D:\FanHubPlus\resources\views/components/site-icon.blade.php ENDPATH**/ ?>
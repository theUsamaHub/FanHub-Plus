<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="dark">
<head>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="theme-color" content="#06060e">
    <title><?php echo $__env->yieldContent('title', 'Fan Hub Plus — Every Universe. One Home.'); ?></title>
    <script>try { document.documentElement.dataset.theme = localStorage.getItem('fanhub-theme') === 'light' ? 'light' : 'dark'; } catch (e) {}</script>
    <?php if(auth()->guard()->check()): ?>
    <meta name="member-preferences-url" content="<?php echo e(route('user.preferences')); ?>">
    <script>
        (() => {
            const theme = <?php echo json_encode(auth()->user()->profile?->theme_preference, 15, 512) ?>;
            if (theme) document.documentElement.dataset.theme = theme === 'system' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : theme;
            document.documentElement.dataset.fontSize = <?php echo json_encode(auth()->user()->profile?->font_size_preference ?? 'medium', 15, 512) ?>;
        })();
    </script>
    <?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/public.js'); ?>
    <?php echo $__env->make('partials.font-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="fh-site">
    <script>
        (function () {
            try {
                if (sessionStorage.getItem('fanhub-splash-shown') === '1') {
                    document.documentElement.dataset.splashSeen = '1';
                }
            } catch (e) {   }
        })();
    </script>
    <div id="splash-screen" data-splash style="position:fixed;inset:0;z-index:9999;background:#000;display:none;align-items:center;justify-content:center;transition:opacity 0.8s ease;">
        <video id="splash-video" class="splash-desktop-only" autoplay muted playsinline preload="auto" style="width:100%;height:100%;object-fit:cover;">
            <source src="<?php echo e(asset('videos/splash screen video.mp4')); ?>" type="video/mp4">
        </video>
        <div class="splash-mobile-only" style="display:none;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
            <style>
                @keyframes splashPulse { 0%,100%{opacity:.3;transform:scale(.95)} 50%{opacity:1;transform:scale(1)} }
                @keyframes splashFadeUp { 0%{opacity:0;transform:translateY(12px)} 100%{opacity:1;transform:translateY(0)} }
                @keyframes splashSpin { 0%{transform:rotate(0deg)} 100%{transform:rotate(360deg)} }
                .splash-mobile-only { animation: splashFadeUp .5s ease forwards; }
                .splash-mobile-only h1 { font-family:'Rajdhani',sans-serif; font-size:32px; font-weight:700; color:#fff; margin:0 0 8px; animation: splashPulse 1.4s ease infinite; letter-spacing:-0.5px; }
                .splash-mobile-only h1 span { color:#FF922E; }
                .splash-mobile-only p { font-family:'Saira',sans-serif; font-size:12px; color:rgba(255,255,255,.5); letter-spacing:4px; text-transform:uppercase; margin:0 0 24px; }
                .splash-ring { width:36px; height:36px; border:2px solid rgba(255,255,255,.1); border-top-color:#FF922E; border-radius:50%; animation: splashSpin .7s linear infinite; }
            </style>
            <h1>FAN<span>HUB+</span></h1>
            <p>Every universe. One home.</p>
            <div class="splash-ring" aria-hidden="true"></div>
        </div>
        <button id="splash-skip" style="position:absolute;top:20px;right:20px;z-index:10000;background:rgba(0,0,0,0.5);color:white;border:1px solid rgba(255,255,255,.3);padding:8px 16px;border-radius:4px;cursor:pointer;font-family:'Saira',sans-serif;font-size:14px;transition:background .2s;">Skip</button>
    </div>
    <style>
        @media(max-width:700px){
            .splash-desktop-only{display:none!important}
            .splash-mobile-only{display:flex!important}
        }
    </style>
    <script>
    (function(){
        var splash=document.getElementById('splash-screen'),
            video=document.getElementById('splash-video'),
            skip=document.getElementById('splash-skip'),
            STORAGE_KEY='fanhub-splash-shown';
        try {
            if (sessionStorage.getItem(STORAGE_KEY) === '1') {
                if (splash) splash.parentNode && splash.parentNode.removeChild(splash);
                return;
            }
        } catch (e) {   }

        if (splash) splash.style.display='flex';

        function markSeenAndHide(){
            try { sessionStorage.setItem(STORAGE_KEY, '1'); } catch (e) {   }
            splash.style.opacity='0';
            setTimeout(function(){ splash.style.display='none'; }, 800);
        }
        if (skip) skip.addEventListener('click', markSeenAndHide);
        if (video) video.addEventListener('ended', markSeenAndHide);
        setTimeout(markSeenAndHide, 2000);
    })();
    </script>

    <a class="fh-skip" href="#main-content">Skip to content</a>
    <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
    <main id="main-content" tabindex="-1" class="fh-main <?php echo $__env->yieldContent('main-class'); ?>"><?php echo $__env->yieldContent('content'); ?></main>
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    <?php if(session('onboarding-success')): ?><div class="onboarding-toast" role="status"><?php echo e(session('onboarding-success')); ?></div><?php endif; ?>
    <?php echo $__env->make('partials.chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.merchandise-feedback', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\FanHubPlus\resources\views/layouts/public.blade.php ENDPATH**/ ?>
-- Laravel Starter Kit Database Backup
-- Date: 2026-09-09 17:31:58

-- Table: activity_logs
TRUNCATE TABLE `activity_logs`;
INSERT INTO `activity_logs` (`id`, `user_id`, `event`, `auditable_type`, `auditable_id`, `old_values`, `new_values`, `ip_address`, `user_agent`, `created_at`, `updated_at`) VALUES ('1', '1', 'deleted', 'App\\Models\\Category', '1', '{\"id\":1,\"name\":\"Technology\",\"slug\":\"technology\",\"description\":\"Technology related items\",\"body\":null,\"image\":null,\"is_active\":true,\"sort_order\":1,\"created_at\":\"2026-09-09T17:12:00.000000Z\",\"updated_at\":\"2026-09-09T17:30:27.000000Z\",\"deleted_at\":\"2026-09-09T17:30:27.000000Z\",\"created_by\":null,\"updated_by\":null}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', '2026-09-09 17:30:27', '2026-09-09 17:30:27');

-- Table: cache
TRUNCATE TABLE `cache`;
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-contacts.new_count', 'i:0;', '1788975139');
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-notifications.recent.1', 'O:55:\"Illuminate\\Notifications\\DatabaseNotificationCollection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '1788975140');
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-notifications.recent.2', 'O:55:\"Illuminate\\Notifications\\DatabaseNotificationCollection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '1788975057');
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-notifications.unread.1', 'i:0;', '1788975140');
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-notifications.unread.2', 'i:0;', '1788975057');
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('laravelstarterkit-cache-settings', 'a:25:{s:9:\"site_name\";a:2:{s:5:\"value\";s:19:\"Laravel Starter Kit\";s:4:\"type\";s:4:\"text\";}s:16:\"site_description\";a:2:{s:5:\"value\";s:38:\"A production-ready Laravel starter kit\";s:4:\"type\";s:8:\"textarea\";}s:9:\"site_logo\";a:2:{s:5:\"value\";N;s:4:\"type\";s:5:\"image\";}s:12:\"site_favicon\";a:2:{s:5:\"value\";N;s:4:\"type\";s:5:\"image\";}s:13:\"contact_email\";a:2:{s:5:\"value\";s:17:\"hello@example.com\";s:4:\"type\";s:4:\"text\";}s:13:\"contact_phone\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:15:\"contact_address\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";}s:10:\"meta_title\";a:2:{s:5:\"value\";s:19:\"Laravel Starter Kit\";s:4:\"type\";s:4:\"text\";}s:16:\"meta_description\";a:2:{s:5:\"value\";s:71:\"A production-ready Laravel starter kit with roles, API, and admin panel\";s:4:\"type\";s:8:\"textarea\";}s:8:\"og_image\";a:2:{s:5:\"value\";N;s:4:\"type\";s:5:\"image\";}s:12:\"facebook_url\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:11:\"twitter_url\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:12:\"linkedin_url\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:10:\"github_url\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:11:\"mail_driver\";a:2:{s:5:\"value\";s:3:\"log\";s:4:\"type\";s:4:\"text\";}s:9:\"mail_host\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:9:\"mail_port\";a:2:{s:5:\"value\";s:3:\"587\";s:4:\"type\";s:6:\"number\";}s:13:\"mail_username\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:13:\"mail_password\";a:2:{s:5:\"value\";s:0:\"\";s:4:\"type\";s:4:\"text\";}s:15:\"mail_encryption\";a:2:{s:5:\"value\";s:3:\"tls\";s:4:\"type\";s:4:\"text\";}s:17:\"mail_from_address\";a:2:{s:5:\"value\";s:17:\"hello@example.com\";s:4:\"type\";s:4:\"text\";}s:14:\"mail_from_name\";a:2:{s:5:\"value\";s:19:\"Laravel Starter Kit\";s:4:\"type\";s:4:\"text\";}s:22:\"mail_additional_emails\";a:2:{s:5:\"value\";s:2:\"[]\";s:4:\"type\";s:4:\"json\";}s:16:\"maintenance_mode\";a:2:{s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";}s:25:\"maintenance_bypass_routes\";a:2:{s:5:\"value\";s:62:\"login,register,forgot-password,reset-password*,admin/* , admin\";s:4:\"type\";s:4:\"text\";}}', '1788978709');

-- Table: categories
TRUNCATE TABLE `categories`;
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `body`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`) VALUES ('1', 'Technology', 'technology', 'Technology related items', NULL, NULL, '1', '1', '2026-09-09 17:12:00', '2026-09-09 17:30:27', '2026-09-09 17:30:27', NULL, NULL);
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `body`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`) VALUES ('2', 'Business', 'business', 'Business related items', NULL, NULL, '1', '2', '2026-09-09 17:12:00', '2026-09-09 17:12:00', NULL, NULL, NULL);
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `body`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`) VALUES ('3', 'Healthcare', 'healthcare', 'Healthcare related items', NULL, NULL, '1', '3', '2026-09-09 17:12:00', '2026-09-09 17:12:00', NULL, NULL, NULL);
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `body`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`) VALUES ('4', 'Education', 'education', 'Education related items', NULL, NULL, '1', '4', '2026-09-09 17:12:00', '2026-09-09 17:12:00', NULL, NULL, NULL);
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `body`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`) VALUES ('5', 'Finance', 'finance', 'Finance related items', NULL, NULL, '1', '5', '2026-09-09 17:12:00', '2026-09-09 17:12:00', NULL, NULL, NULL);

-- Table: migrations
TRUNCATE TABLE `migrations`;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('1', '0001_01_01_000000_create_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('2', '0001_01_01_000001_create_cache_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('3', '0001_01_01_000002_create_jobs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('4', '2024_01_01_000001_create_roles_and_permissions_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('5', '2024_01_01_000002_create_categories_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('6', '2026_07_02_185533_create_personal_access_tokens_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('7', '2026_07_24_165147_create_contacts_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('8', '2026_07_24_175801_create_media_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('9', '2026_07_24_175801_create_settings_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('10', '2026_07_24_175801_create_validation_rules_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('11', '2026_07_24_180000_add_image_to_categories_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('12', '2026_07_24_205900_create_tags_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('13', '2026_07_24_205910_create_activity_logs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('14', '2026_07_24_210000_add_body_to_categories_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('15', '2026_07_24_210100_add_permissions_to_roles_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('16', '2026_07_28_175845_make_mediable_nullable_in_media_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('17', '2026_07_29_072909_add_scheduling_to_categories_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('18', '2026_07_29_073215_create_notifications_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('19', '2026_07_29_073553_create_subscribers_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('20', '2026_07_29_130955_add_performance_indexes', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('21', '2026_08_06_154328_drop_validation_rules_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('22', '2026_08_16_204111_drop_published_at_and_unpublish_at_from_categories_table', '1');

-- Table: role_user
TRUNCATE TABLE `role_user`;
INSERT INTO `role_user` (`user_id`, `role_id`) VALUES ('1', '1');
INSERT INTO `role_user` (`user_id`, `role_id`) VALUES ('2', '2');

-- Table: roles
TRUNCATE TABLE `roles`;
INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `permissions`, `created_at`, `updated_at`) VALUES ('1', 'Admin', 'admin', 'Full system access. Can manage all resources, users, and settings.', NULL, '2026-09-09 17:11:59', '2026-09-09 17:11:59');
INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `permissions`, `created_at`, `updated_at`) VALUES ('2', 'User', 'user', 'Standard user access. Can view and manage own profile.', NULL, '2026-09-09 17:12:00', '2026-09-09 17:12:00');

-- Table: sessions
TRUNCATE TABLE `sessions`;
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES ('QsdgUlp8mweBdiyCZQNV5oa9M3zYFFfLQeGss0Iz', '1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJQZTNTY2RSaThuc0phOGZFeW85MjlJRWRPMlVSSDU3bmdCenBKY0tRIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2FkbWluXC9iYWNrdXAifSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9', '1788975116');

-- Table: settings
TRUNCATE TABLE `settings`;
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('1', 'general', 'site_name', 'Laravel Starter Kit', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('2', 'general', 'site_description', 'A production-ready Laravel starter kit', 'textarea', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('3', 'general', 'site_logo', NULL, 'image', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('4', 'general', 'site_favicon', NULL, 'image', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('5', 'general', 'contact_email', 'hello@example.com', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('6', 'general', 'contact_phone', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('7', 'general', 'contact_address', '', 'textarea', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('8', 'seo', 'meta_title', 'Laravel Starter Kit', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('9', 'seo', 'meta_description', 'A production-ready Laravel starter kit with roles, API, and admin panel', 'textarea', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('10', 'seo', 'og_image', NULL, 'image', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('11', 'social', 'facebook_url', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('12', 'social', 'twitter_url', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('13', 'social', 'linkedin_url', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('14', 'social', 'github_url', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('15', 'mail', 'mail_driver', 'log', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('16', 'mail', 'mail_host', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('17', 'mail', 'mail_port', '587', 'number', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('18', 'mail', 'mail_username', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('19', 'mail', 'mail_password', '', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('20', 'mail', 'mail_encryption', 'tls', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('21', 'mail', 'mail_from_address', 'hello@example.com', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('22', 'mail', 'mail_from_name', 'Laravel Starter Kit', 'text', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('23', 'mail', 'mail_additional_emails', '[]', 'json', '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('24', 'general', 'maintenance_mode', '0', 'boolean', '2026-09-09 17:31:26', '2026-09-09 17:31:49');
INSERT INTO `settings` (`id`, `group`, `key`, `value`, `type`, `created_at`, `updated_at`) VALUES ('25', 'general', 'maintenance_bypass_routes', 'login,register,forgot-password,reset-password*,admin/* , admin', 'text', '2026-09-09 17:31:39', '2026-09-09 17:31:39');

-- Table: users
TRUNCATE TABLE `users`;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('1', 'Admin User', 'admin@example.com', '2026-09-09 17:12:00', '$2y$12$jH.cJOPzPY53uUJj4Tltr.wbXidUCleEMbAjCRdh0qTshK50kFklW', NULL, '2026-09-09 17:12:00', '2026-09-09 17:12:00');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('2', 'Test User', 'user@example.com', '2026-09-09 17:12:00', '$2y$12$Ij5MZ3bndp7zDQ3UEagrO.HWpoUCTfj7jOmaKLNtDgvsUCYSYTf66', NULL, '2026-09-09 17:12:00', '2026-09-09 17:12:00');


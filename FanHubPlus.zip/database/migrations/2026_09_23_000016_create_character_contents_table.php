<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('character_contents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('character_id')->constrained('character_profiles')->cascadeOnDelete();
            $table->foreignId('content_id')->constrained('contents')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['character_id', 'content_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('character_contents');
    }
};

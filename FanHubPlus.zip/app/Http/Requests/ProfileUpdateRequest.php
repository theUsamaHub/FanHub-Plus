<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProfileUpdateRequest extends FormRequest
{
    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['sometimes', 'required', 'string', 'lowercase', 'email', 'max:255', Rule::unique('users')->ignore($this->user()->id)],
            'avatar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,gif,webp', 'max:2048'],
        ];

        if ($this->user()->hasRole('admin')) {
            $rules['remove_avatar'] = ['nullable', 'boolean'];

            return $rules;
        }

        $rules += [
            'display_name' => ['nullable', 'string', 'max:100'],
            'bio' => ['nullable', 'string', 'max:2000'],
            'google_maps_location' => ['nullable', 'url:http,https', 'max:500'],
            'remove_avatar' => ['nullable', 'boolean'],
            'avatar_media_id' => ['nullable', 'integer', Rule::exists('media', 'id')->where('uploaded_by', $this->user()->id)->where('media_type', 'image')],
            'favorites_present' => ['nullable', 'boolean'],
            'favorites' => ['nullable', 'array', 'max:100'],
            'favorites.*' => ['integer', 'distinct', Rule::exists('categories', 'id')->whereNull('deleted_at')],
        ];

        return $rules;
    }
}
